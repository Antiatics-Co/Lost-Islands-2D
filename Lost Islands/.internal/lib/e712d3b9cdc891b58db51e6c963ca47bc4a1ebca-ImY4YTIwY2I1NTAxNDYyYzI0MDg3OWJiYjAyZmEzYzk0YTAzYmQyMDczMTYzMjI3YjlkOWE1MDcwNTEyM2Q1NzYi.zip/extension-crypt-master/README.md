[![Actions Status Alpha](https://github.com/defold/extension-crypt/actions/workflows/bob.yml/badge.svg)](https://github.com/defold/extension-crypt/actions)

# Cryptographic functions for Defold

Defold [native extension](https://www.defold.com/manuals/extensions/) for interacting with various hash and encode/decode algorithms.

[Manual, API and setup instructions](https://www.defold.com/extension-crypt/) is available on the official Defold site.
